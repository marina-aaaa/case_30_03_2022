﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Case2.pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Case2.pages.Tests
{
    [TestClass()]
    public class vhodTestsTrue
    {
        [TestMethod()]
        public void CheckPassTestTrue()
        {
            string pass = "admin";
            string expected = "admin";
            string actual = vhod.CheckPass(pass);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod()]
        public void CheckPassTestFalse()
        {
                string pass = "qwer";
                bool expected = false;
                string actual = vhod.CheckPass(pass);
                Assert.IsFalse(expected, actual);

            }
        [TestMethod()]
        public void CheckPassLenghtTestTrue()
        {
            string pass = "admin";
            string expected = "admin";
            bool expected1 = true;
            string actual = vhod.CheckPassLenght(pass);
            if (pass.Length < 3 || pass.Length > 20)
            {
                Assert.AreEqual(expected, actual);
                
            }
            else
            {
                Assert.IsTrue(expected1, actual);
            }

        
                
        }
        [TestMethod()]
        public void CheckPassLenghtTestTrueFalse()
        {
            string pass = "qwe";
            string expected = "qwe";
            bool expected1 = true;
            string actual = vhod.CheckPassLenght(pass);
            if (pass.Length < 3 || pass.Length > 20)
            {
                Assert.AreEqual(expected, actual);

            }
            else
            {
                Assert.IsTrue(expected1, actual);
            }

        }
    }
    

}
    
