﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Case2.source
{
    class FrameApp
    {
        public static Frame frmObj;
        public static CaseQualEntities1 db = new CaseQualEntities1();
        public static int UserID = 0;
    }
}
