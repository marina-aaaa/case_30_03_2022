﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Case2.source
{
    class OdbConnectHelper
    {
        public static CaseQualEntities1 entobj = new CaseQualEntities1();
    }
}
