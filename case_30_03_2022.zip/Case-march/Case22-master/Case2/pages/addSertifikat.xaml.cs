﻿using Case2.source;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;

namespace Case2.pages
{
    /// <summary>
    /// Логика взаимодействия для addSertifikat.xaml
    /// </summary>
    public partial class addSertifikat : Page
    {
        public addSertifikat()
        {
            InitializeComponent();
            FrameApp.db.Teachers.Load();
            FrameApp.db.Courses.Load();
            foreach (var a in FrameApp.db.Teachers.Local)
            {
                if (!a.IsStudent)
                {
                    txb_prepod.Items.Add(a.FIO);
                }
            }
            foreach (var a in FrameApp.db.Courses.Local)
            {
                txb_kurs.Items.Add(a.Name);
            }
        }

        private void btn_addSert_Click(object sender, RoutedEventArgs e)
        {
            var prepod = FrameApp.db.Teachers.FirstOrDefault(x => x.FIO == txb_prepod.SelectedItem.ToString());
            var kurs = FrameApp.db.Subjects.FirstOrDefault(x => x.Name == txb_kurs.SelectedItem.ToString());
            var Sert = new Certificates()
            {
                TeacherID = prepod.id,
                CourseID = kurs.id,

            };
            FrameApp.db.Certificates.Add(Sert);
            FrameApp.db.SaveChanges();
            MessageBox.Show("Сертификат создан");
            FrameApp.frmObj.Navigate(new pageAdmin());
        }

        private void btn_Excel_Click(object sender, RoutedEventArgs e)
        {
            var allSert = OdbConnectHelper.entobj.Certificates.ToList().OrderBy(p => p.TeacherID).ToList();

            var application = new Excel.Application();
            application.SheetsInNewWorkbook = 1;

            Excel.Workbook workbook = application.Workbooks.Add(Type.Missing);
            Excel.Worksheet worksheet = application.Worksheets.Item[1];
            worksheet.Name = "Сертификаты";
            worksheet.Cells[1][1] = "id Учителя";
            worksheet.Cells[2][1] = "id Курса";
            worksheet.Cells[3][1] = "Дата";
            for (int i = 0; i < allSert.Count(); i++)
            {
                worksheet.Cells[1][i + 2] = allSert[i].TeacherID;
                worksheet.Cells[2][i + 2] = allSert[i].CourseID;
                worksheet.Cells[3][i + 2] = allSert[i].Date;
            }
            Excel.Range rangeBorders = worksheet.Range[worksheet.Cells[1][1], worksheet.Cells[3][allSert.Count() + 2]];
            rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;
            worksheet.Columns.AutoFit();
            application.Visible = true;
        }
    }
}
