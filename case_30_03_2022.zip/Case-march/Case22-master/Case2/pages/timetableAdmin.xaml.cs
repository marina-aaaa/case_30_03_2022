﻿using Case2.source;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Word = Microsoft.Office.Interop.Word;
using Excel = Microsoft.Office.Interop.Excel;

namespace Case2.pages
{
    /// <summary>
    /// Логика взаимодействия для timetableAdmin.xaml
    /// </summary>
    public partial class timetableAdmin : Page
    {
        CaseQualEntities1 db;
        public timetableAdmin()
        {
            InitializeComponent();
            db = new CaseQualEntities1();
            db.CoursesSchedules.Load();
        }
        private void btn_excel_Click(object sender, RoutedEventArgs e)
        {
            var alltimetable = OdbConnectHelper.entobj.CoursesSchedules.ToList().OrderBy(p => p.id).ToList();

            var application = new Excel.Application();
            application.SheetsInNewWorkbook = 1;

            Excel.Workbook workbook = application.Workbooks.Add(Type.Missing);
            Excel.Worksheet worksheet = application.Worksheets.Item[1];
            worksheet.Name = "Расписние";
            worksheet.Cells[1][1] = "id Расписания";
            worksheet.Cells[2][1] = "id Дня недели";
            worksheet.Cells[3][1] = "Id Предмета";
            worksheet.Cells[4][1] = "Номер";
            worksheet.Cells[5][1] = "id Группы";
            for (int i = 0; i < alltimetable.Count(); i++)
            {
                worksheet.Cells[1][i + 2] = alltimetable[i].id;
                worksheet.Cells[2][i + 2] = alltimetable[i].DayOfWeekID;
                worksheet.Cells[3][i + 2] = alltimetable[i].SubjectID;
                worksheet.Cells[4][i + 2] = alltimetable[i].Number;
                worksheet.Cells[5][i + 2] = alltimetable[i].GroupID;
            }
            Excel.Range rangeBorders = worksheet.Range[worksheet.Cells[1][1], worksheet.Cells[5][alltimetable.Count() + 2]];
            rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;
            worksheet.Columns.AutoFit();
            application.Visible = true;
        }

        private void btn_word_Click(object sender, RoutedEventArgs e)
        {
            var alltimetable = OdbConnectHelper.entobj.CoursesSchedules.OrderBy(p => p.id).ToList();
            var application = new Word.Application();
            Word.Document document = application.Documents.Add();
            Word.Paragraph paragraph = document.Paragraphs.Add();
            Word.Range userRange = paragraph.Range;
            userRange.Text = "Расписание";
            userRange.InsertParagraphAfter();
            Word.Paragraph tableparagraph = document.Paragraphs.Add();
            Word.Range tableRange = tableparagraph.Range;
            Word.Table infoTable = document.Tables.Add(tableRange, alltimetable.Count(), 5);
            infoTable.Borders.InsideLineStyle = infoTable.Borders.OutsideLineStyle
                    = Word.WdLineStyle.wdLineStyleSingle;
            infoTable.Range.Cells.VerticalAlignment
                    = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
            Word.Range cellRange;
            cellRange = infoTable.Cell(1, 1).Range;
            cellRange.Text = "id Расписания";
            cellRange = infoTable.Cell(1, 2).Range;
            cellRange.Text = "id Дня недели";
            cellRange = infoTable.Cell(1, 3).Range;
            cellRange.Text = "Id Предмета";
            cellRange = infoTable.Cell(1, 4).Range;
            cellRange.Text = "Номер";
            cellRange = infoTable.Cell(1, 5).Range;
            cellRange.Text = "id Группы";
            infoTable.Rows[1].Range.Bold = 1;
            for (int i = 0; i < alltimetable.Count(); i++)
            {
                cellRange = infoTable.Cell(i + 2, 1).Range;
                cellRange.Text = alltimetable[i].id.ToString();
                cellRange = infoTable.Cell(i + 2, 2).Range;
                cellRange.Text = alltimetable[i].DayOfWeekID.ToString();
                cellRange = infoTable.Cell(i + 2, 3).Range;
                cellRange.Text = alltimetable[i].SubjectID.ToString();
                cellRange = infoTable.Cell(i + 2, 4).Range;
                cellRange.Text = alltimetable[i].Number.ToString();
                cellRange = infoTable.Cell(i + 2, 5).Range;
                cellRange.Text = alltimetable[i].GroupID.ToString();
            }
            application.Visible = true;
        }
    }
}
