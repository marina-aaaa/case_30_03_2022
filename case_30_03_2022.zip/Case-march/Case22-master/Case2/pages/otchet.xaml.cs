﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Word = Microsoft.Office.Interop.Word;
using Excel = Microsoft.Office.Interop.Excel;
using Case2.source;
using System.Data.Entity;

namespace Case2.pages
{
    /// <summary>
    /// Логика взаимодействия для otchet.xaml
    /// </summary>
    public partial class otchet : Page
    {
        CaseQualEntities1 db;
        public otchet()
        {
            InitializeComponent();
            db = new CaseQualEntities1();
            db.Teachers.Load();
            db.Courses.Load();
        }

        private void Excelbt_Click(object sender, RoutedEventArgs e)
        {
            var allSert = OdbConnectHelper.entobj.Certificates.ToList().OrderBy(p => p.TeacherID).ToList();

            var application = new Excel.Application();
            application.SheetsInNewWorkbook = 1;

            Excel.Workbook workbook = application.Workbooks.Add(Type.Missing);
            Excel.Worksheet worksheet = application.Worksheets.Item[1];
            worksheet.Name = "Сертификаты";
            worksheet.Cells[1][1] = "id Учителя";
            worksheet.Cells[2][1] = "id Курса";
            worksheet.Cells[3][1] = "Дата";
            for (int i = 0; i < allSert.Count(); i++)
            {
                worksheet.Cells[1][i + 2] = allSert[i].TeacherID;
                worksheet.Cells[2][i + 2] = allSert[i].CourseID;
                worksheet.Cells[3][i + 2] = allSert[i].Date;
            }
            Excel.Range rangeBorders = worksheet.Range[worksheet.Cells[1][1], worksheet.Cells[3][allSert.Count() + 2]];
            rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeBottom].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeLeft].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeRight].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlEdgeTop].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlInsideHorizontal].LineStyle =
            rangeBorders.Borders[Excel.XlBordersIndex.xlInsideVertical].LineStyle = Excel.XlLineStyle.xlContinuous;
            worksheet.Columns.AutoFit();
            application.Visible = true;
        }

        private void Wordbt_Click(object sender, RoutedEventArgs e)
        {
            var allEventplans = OdbConnectHelper.entobj.Certificates.OrderBy(p => p.id).ToList();
            var application = new Word.Application();
            Word.Document document = application.Documents.Add();
            Word.Paragraph paragraph = document.Paragraphs.Add();
            Word.Range userRange = paragraph.Range;
            userRange.Text = "Сертификаты";
            userRange.InsertParagraphAfter();
            Word.Paragraph tableparagraph = document.Paragraphs.Add();
            Word.Range tableRange = tableparagraph.Range;
            Word.Table infoTable = document.Tables.Add(tableRange, allEventplans.Count(), 3);
            infoTable.Borders.InsideLineStyle = infoTable.Borders.OutsideLineStyle
                    = Word.WdLineStyle.wdLineStyleSingle;
            infoTable.Range.Cells.VerticalAlignment
                    = Word.WdCellVerticalAlignment.wdCellAlignVerticalCenter;
            Word.Range cellRange;
            cellRange = infoTable.Cell(1, 1).Range;
            cellRange.Text = "id Учителя";
            cellRange = infoTable.Cell(1, 2).Range;
            cellRange.Text = "id Rehcf";
            cellRange = infoTable.Cell(1, 3).Range;
            cellRange.Text = "Дата";
            infoTable.Rows[1].Range.Bold = 1;
            for (int i = 0; i < allEventplans.Count(); i++)
            {
                cellRange = infoTable.Cell(i + 2, 1).Range;
                cellRange.Text = allEventplans[i].CourseID.ToString();
                cellRange = infoTable.Cell(i + 2, 2).Range;
                cellRange.Text = allEventplans[i].TeacherID.ToString();
                cellRange = infoTable.Cell(i + 2, 3).Range;
                cellRange.Text = allEventplans[i].Date.ToString();
            }
            application.Visible = true;
        }
    }
}
